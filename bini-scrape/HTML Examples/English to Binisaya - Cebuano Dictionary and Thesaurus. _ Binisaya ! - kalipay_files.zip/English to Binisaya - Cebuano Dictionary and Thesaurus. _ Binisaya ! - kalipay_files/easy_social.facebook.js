/**
 * Easy Social - Add external facebook js
 */
$(document).ready(function() {
  $.getScript('http://static.ak.fbcdn.net/connect.php/js/FB.Share');
});