/**
 * Easy Social - Add external twitter js
 */
$(document).ready(function() {
  $.getScript('http://platform.twitter.com/widgets.js');
});