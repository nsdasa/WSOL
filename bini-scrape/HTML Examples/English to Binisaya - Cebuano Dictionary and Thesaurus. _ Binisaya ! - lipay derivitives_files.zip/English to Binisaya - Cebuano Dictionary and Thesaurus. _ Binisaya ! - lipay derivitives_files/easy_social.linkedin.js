/**
 * Easy Social - Add external linkedin js
 */
$(document).ready(function() {
  $.getScript('http://platform.linkedin.com/in.js');
});